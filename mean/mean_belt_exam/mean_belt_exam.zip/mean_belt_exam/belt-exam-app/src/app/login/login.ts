export class Login {
    constructor(
        public username: string= ""
    ) {}
}
