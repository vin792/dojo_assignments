export class Bid {
    constructor(
        public username: string= "",
        public bid: number= null,
        public productID: string = ""
    ) {}
}