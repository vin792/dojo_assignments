Folder containing all assignments done at coding dojo in the various stacks
